package com.learning.kafka.service;

import com.learning.kafka.model.Department;

public interface DepartmentService {

    void processDepartmentRequest(Department department);
}
